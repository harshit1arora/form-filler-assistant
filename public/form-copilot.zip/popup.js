/**
 * Popup Script — Form Copilot
 */

const DEFAULT_CRM = {
  name: "Jane Doe",
  first_name: "Jane",
  last_name: "Doe",
  email: "jane.doe@acme.com",
  phone: "+1-555-867-5309",
  company: "Acme Corp",
  job_title: "VP of Sales",
  address: "742 Evergreen Terrace",
  city: "Springfield",
  state: "IL",
  zip: "62704",
  country: "United States",
  website: "https://acme.com",
  notes: "Key decision maker. Prefers email.",
};

const CRM_KEYS = [
  "name", "first_name", "last_name", "email", "phone",
  "company", "job_title", "address", "city", "state",
  "zip", "country", "website"
];

const statusEl = document.getElementById("status");
const autofillBtn = document.getElementById("autofill-btn");
const scanBtn = document.getElementById("scan-btn");
const clearBtn = document.getElementById("clear-btn");
const toggleLink = document.getElementById("toggle-fields");
const crmFieldsEl = document.getElementById("crm-fields");
const scanResultsEl = document.getElementById("scan-results");

function setStatus(text, type = "") {
  statusEl.textContent = text;
  statusEl.className = type;
}

// ─── CRM Data Persistence ───────────────────────────────────

function loadCrmData() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["crm_data"], (result) => {
      resolve(result.crm_data || DEFAULT_CRM);
    });
  });
}

function saveCrmData(data) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ crm_data: data }, resolve);
  });
}

function readFieldsFromUI() {
  const data = {};
  CRM_KEYS.forEach((key) => {
    const el = document.getElementById(`crm-${key}`);
    if (el) data[key] = el.value;
  });
  data.notes = DEFAULT_CRM.notes;
  return data;
}

function populateUI(data) {
  CRM_KEYS.forEach((key) => {
    const el = document.getElementById(`crm-${key}`);
    if (el) el.value = data[key] || "";
  });
}

// ─── Init ───────────────────────────────────────────────────

loadCrmData().then(populateUI);

toggleLink.addEventListener("click", () => {
  const hidden = crmFieldsEl.classList.toggle("hidden");
  toggleLink.textContent = hidden ? "✏️ Edit CRM Data" : "▲ Hide CRM Data";
});

CRM_KEYS.forEach((key) => {
  const el = document.getElementById(`crm-${key}`);
  if (el) {
    el.addEventListener("input", async () => {
      await saveCrmData(readFieldsFromUI());
    });
  }
});

// ─── Helpers ────────────────────────────────────────────────

async function injectAndSend(action) {
  const crmData = readFieldsFromUI();
  await saveCrmData(crmData);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab");

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["content.js"],
  });

  return chrome.tabs.sendMessage(tab.id, { action, crmData });
}

// ─── Scan ───────────────────────────────────────────────────

scanBtn.addEventListener("click", async () => {
  scanBtn.disabled = true;
  setStatus("Scanning…");
  scanResultsEl.classList.add("hidden");

  try {
    const result = await injectAndSend("scan");

    if (result) {
      setStatus(`Scanned ${result.total} fields`, "success");
      scanResultsEl.innerHTML = `
        <span class="dot dot-green"></span>${result.high} matched (high)&nbsp;&nbsp;
        <span class="dot dot-yellow"></span>${result.medium} medium&nbsp;&nbsp;
        <span class="dot dot-red"></span>${result.none} unmatched
      `;
      scanResultsEl.classList.remove("hidden");
    }
  } catch (err) {
    console.error("[Form Copilot]", err);
    setStatus("Scan failed — check console", "error");
  } finally {
    scanBtn.disabled = false;
  }
});

// ─── Autofill ───────────────────────────────────────────────

autofillBtn.addEventListener("click", async () => {
  autofillBtn.disabled = true;
  setStatus("Filling…");

  try {
    const result = await injectAndSend("autofill");

    if (result && result.filled > 0) {
      setStatus(`✓ Filled ${result.filled} of ${result.total} fields`, "success");
    } else if (result) {
      setStatus("No matching fields found", "error");
    }
    scanResultsEl.classList.add("hidden");
  } catch (err) {
    console.error("[Form Copilot]", err);
    setStatus("Failed — check console", "error");
  } finally {
    autofillBtn.disabled = false;
  }
});

// ─── Clear ──────────────────────────────────────────────────

clearBtn.addEventListener("click", () => {
  chrome.storage.local.remove(["learned_mappings", "crm_data"], () => {
    populateUI(DEFAULT_CRM);
    scanResultsEl.classList.add("hidden");
    setStatus("All data cleared", "success");
  });
});
