/**
 * Field Mapping Engine
 * 
 * Heuristic matching: builds a signature string from field metadata
 * and matches against known CRM field keywords.
 * 
 * Includes a confidence score (high/medium/low) for each match.
 * Supports a learning system: domain-specific overrides from chrome.storage.
 */

const FIELD_RULES = [
  { crmKey: "first_name", keywords: ["first_name", "firstname", "first name", "fname", "given_name", "givenname"], confidence: "high" },
  { crmKey: "last_name",  keywords: ["last_name", "lastname", "last name", "lname", "surname", "family_name", "familyname"], confidence: "high" },
  { crmKey: "name",       keywords: ["name", "full_name", "fullname", "your name", "contact_name"], confidence: "medium" },
  { crmKey: "email",      keywords: ["email", "e-mail", "mail", "email_address", "emailaddress"], confidence: "high" },
  { crmKey: "phone",      keywords: ["phone", "tel", "telephone", "mobile", "cell", "phone_number", "phonenumber"], confidence: "high" },
  { crmKey: "company",    keywords: ["company", "organization", "org", "business", "company_name", "employer"], confidence: "high" },
  { crmKey: "job_title",  keywords: ["job_title", "jobtitle", "title", "role", "position", "job title"], confidence: "medium" },
  { crmKey: "address",    keywords: ["address", "street", "street_address", "address1", "address_line_1", "addr"], confidence: "high" },
  { crmKey: "city",       keywords: ["city", "town", "locality"], confidence: "high" },
  { crmKey: "state",      keywords: ["state", "province", "region"], confidence: "high" },
  { crmKey: "zip",        keywords: ["zip", "zipcode", "zip_code", "postal", "postal_code", "postcode"], confidence: "high" },
  { crmKey: "country",    keywords: ["country", "nation"], confidence: "high" },
  { crmKey: "website",    keywords: ["website", "url", "web", "homepage", "site"], confidence: "medium" },
  { crmKey: "notes",      keywords: ["notes", "comments", "message", "description", "info", "additional"], confidence: "low" },
];

/**
 * Build a lowercase signature string from all metadata about a field.
 */
function buildSignature(field) {
  return [field.name, field.placeholder, field.label, field.type, field.id]
    .filter(Boolean)
    .join(" ")
    .toLowerCase()
    .replace(/[^a-z0-9_ ]/g, " ");
}

/**
 * Match a single field to a CRM key using heuristic rules.
 * Returns { crmKey, confidence } or null.
 */
function matchField(field) {
  const sig = buildSignature(field);
  if (!sig.trim()) return null;

  // Exact-ish matching: walk rules in order (specific → general)
  for (const rule of FIELD_RULES) {
    for (const kw of rule.keywords) {
      if (sig.includes(kw)) {
        return { crmKey: rule.crmKey, confidence: rule.confidence };
      }
    }
  }

  // Input type heuristics
  if (field.type === "email") return { crmKey: "email", confidence: "medium" };
  if (field.type === "tel")   return { crmKey: "phone", confidence: "medium" };
  if (field.type === "url")   return { crmKey: "website", confidence: "medium" };

  return null;
}

/**
 * Map an array of detected fields to CRM keys.
 * Returns array of { field, crmKey, confidence }.
 */
function mapFields(fields) {
  return fields.map((field) => {
    const match = matchField(field);
    return {
      field,
      crmKey: match ? match.crmKey : null,
      confidence: match ? match.confidence : null,
    };
  });
}

/**
 * LLM mapping fallback (mock).
 * In production, this would call an LLM API to infer field→CRM mapping.
 */
async function llmMapFields(fields) {
  console.log("[Form Copilot] LLM mapping fallback invoked (mock). Fields:", fields.length);
  // Returns empty — the caller should treat this as "no additional mappings"
  return [];
}

// Export for content script (injected as IIFE, so we attach to window)
if (typeof window !== "undefined") {
  window.__FC_Mapping = { mapFields, llmMapFields };
}
