/**
 * Content Script — Form Copilot
 *
 * 1. Scans the DOM for form fields.
 * 2. Maps fields to CRM schema via heuristic engine.
 * 3. Shows a visual overlay with color-coded field highlights.
 * 4. Autofills matched fields and dispatches React-compatible events.
 * 5. Watches for user corrections and persists them for future visits.
 */

(function () {
  "use strict";

  // ─── FORM DETECTION ───────────────────────────────────────────

  function findLabel(el) {
    if (el.id) {
      const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (label) return label.textContent.trim();
    }
    const parent = el.closest("label");
    if (parent) return parent.textContent.trim();
    if (el.getAttribute("aria-label")) return el.getAttribute("aria-label").trim();
    const prev = el.previousElementSibling;
    if (prev && (prev.tagName === "LABEL" || prev.tagName === "SPAN")) {
      return prev.textContent.trim();
    }
    return "";
  }

  function isVisible(el) {
    if (el.type === "hidden") return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
    if (el.offsetWidth === 0 && el.offsetHeight === 0) return false;
    return true;
  }

  function detectFields() {
    const elements = document.querySelectorAll("input, textarea, select");
    const fields = [];
    const skipTypes = ["submit", "button", "reset", "file", "image", "checkbox", "radio"];

    elements.forEach((el) => {
      if (!isVisible(el)) return;
      if (el.tagName === "INPUT" && skipTypes.includes(el.type)) return;

      fields.push({
        element: el,
        tag: el.tagName.toLowerCase(),
        type: el.type || "",
        name: el.name || "",
        id: el.id || "",
        placeholder: el.placeholder || "",
        label: findLabel(el),
      });
    });

    return fields;
  }

  // ─── MAPPING ──────────────────────────────────────────────────

  const FIELD_RULES = [
    { crmKey: "first_name", keywords: ["first_name", "firstname", "first name", "fname", "given_name", "givenname", "first-name"] },
    { crmKey: "last_name",  keywords: ["last_name", "lastname", "last name", "lname", "surname", "family_name", "familyname", "last-name"] },
    { crmKey: "name",       keywords: ["full_name", "fullname", "full name", "your name", "contact_name", "your-name"] },
    { crmKey: "email",      keywords: ["email", "e-mail", "mail", "email_address", "emailaddress", "e_mail"] },
    { crmKey: "phone",      keywords: ["phone", "tel", "telephone", "mobile", "cell", "phone_number", "phonenumber"] },
    { crmKey: "company",    keywords: ["company", "organization", "org", "business", "company_name", "employer"] },
    { crmKey: "job_title",  keywords: ["job_title", "jobtitle", "title", "role", "position", "job title", "job-title"] },
    { crmKey: "address",    keywords: ["address", "street", "street_address", "address1", "address_line_1", "addr", "location"] },
    { crmKey: "city",       keywords: ["city", "town", "locality"] },
    { crmKey: "state",      keywords: ["state", "province", "region"] },
    { crmKey: "zip",        keywords: ["zip", "zipcode", "zip_code", "postal", "postal_code", "postcode"] },
    { crmKey: "country",    keywords: ["country", "nation"] },
    { crmKey: "website",    keywords: ["website", "url", "web", "homepage", "site"] },
    { crmKey: "notes",      keywords: ["notes", "comments", "message", "description", "info", "additional"] },
  ];

  function buildSignature(field) {
    return [field.name, field.placeholder, field.label, field.type, field.id]
      .filter(Boolean).join(" ").toLowerCase().replace(/[^a-z0-9_ -]/g, " ");
  }

  function matchField(field) {
    const sig = buildSignature(field);
    if (!sig.trim()) return null;

    for (const rule of FIELD_RULES) {
      for (const kw of rule.keywords) {
        if (sig.includes(kw)) return rule.crmKey;
      }
    }

    if (sig.includes("name")) return "name";
    if (field.type === "email") return "email";
    if (field.type === "tel")   return "phone";
    if (field.type === "url")   return "website";

    return null;
  }

  // Confidence: high if learned or exact keyword, medium for type fallback, low for broad "name"
  function matchFieldWithConfidence(field, learned) {
    const fid = fieldIdentifier(field);

    if (fid && learned[fid]) {
      return { crmKey: learned[fid], confidence: "high", source: "learned" };
    }

    const sig = buildSignature(field);
    if (!sig.trim()) return { crmKey: null, confidence: null, source: null };

    for (const rule of FIELD_RULES) {
      for (const kw of rule.keywords) {
        if (sig.includes(kw)) {
          return { crmKey: rule.crmKey, confidence: "high", source: "heuristic" };
        }
      }
    }

    if (sig.includes("name")) return { crmKey: "name", confidence: "medium", source: "heuristic" };
    if (field.type === "email") return { crmKey: "email", confidence: "medium", source: "type" };
    if (field.type === "tel")   return { crmKey: "phone", confidence: "medium", source: "type" };
    if (field.type === "url")   return { crmKey: "website", confidence: "medium", source: "type" };

    return { crmKey: null, confidence: null, source: null };
  }

  // ─── VISUAL OVERLAY ───────────────────────────────────────────

  const OVERLAY_CLASS = "__fc-overlay";
  const BADGE_CLASS = "__fc-badge";

  function injectOverlayStyles() {
    if (document.getElementById("__fc-styles")) return;
    const style = document.createElement("style");
    style.id = "__fc-styles";
    style.textContent = `
      .__fc-overlay {
        position: absolute;
        pointer-events: none;
        border-radius: 4px;
        z-index: 2147483646;
        transition: opacity 0.3s ease;
        box-sizing: border-box;
      }
      .__fc-overlay--high {
        border: 2px solid #22c55e;
        background: rgba(34, 197, 94, 0.08);
        box-shadow: 0 0 8px rgba(34, 197, 94, 0.25);
      }
      .__fc-overlay--medium {
        border: 2px solid #eab308;
        background: rgba(234, 179, 8, 0.08);
        box-shadow: 0 0 8px rgba(234, 179, 8, 0.25);
      }
      .__fc-overlay--none {
        border: 2px solid #ef4444;
        background: rgba(239, 68, 68, 0.08);
        box-shadow: 0 0 8px rgba(239, 68, 68, 0.25);
      }
      .__fc-badge {
        position: absolute;
        top: -10px;
        right: -4px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 1px 6px;
        border-radius: 4px;
        color: #fff;
        white-space: nowrap;
        pointer-events: none;
        z-index: 2147483647;
        line-height: 16px;
        letter-spacing: 0.02em;
      }
      .__fc-badge--high { background: #16a34a; }
      .__fc-badge--medium { background: #ca8a04; }
      .__fc-badge--none { background: #dc2626; }
      .__fc-summary {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #0f172a;
        color: #e2e8f0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 13px;
        padding: 14px 18px;
        border-radius: 12px;
        z-index: 2147483647;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        border: 1px solid #1e293b;
        line-height: 1.5;
        max-width: 280px;
      }
      .__fc-summary strong { color: #fff; }
      .__fc-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; vertical-align: middle; }
      .__fc-dot--green { background: #22c55e; }
      .__fc-dot--yellow { background: #eab308; }
      .__fc-dot--red { background: #ef4444; }
    `;
    document.head.appendChild(style);
  }

  function clearOverlays() {
    document.querySelectorAll(`.${OVERLAY_CLASS}, .__fc-summary`).forEach(el => el.remove());
  }

  function createOverlay(fieldEl, confidence, crmKey) {
    const rect = fieldEl.getBoundingClientRect();
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;

    const level = confidence || "none";

    const overlay = document.createElement("div");
    overlay.className = `${OVERLAY_CLASS} __fc-overlay--${level}`;
    overlay.style.left = (rect.left + scrollX - 3) + "px";
    overlay.style.top = (rect.top + scrollY - 3) + "px";
    overlay.style.width = (rect.width + 6) + "px";
    overlay.style.height = (rect.height + 6) + "px";
    overlay.style.position = "absolute";

    const badge = document.createElement("div");
    badge.className = `${BADGE_CLASS} __fc-badge--${level}`;
    badge.textContent = crmKey ? `→ ${crmKey}` : "no match";
    overlay.appendChild(badge);

    document.body.appendChild(overlay);
    return overlay;
  }

  function showSummary(counts) {
    const summary = document.createElement("div");
    summary.className = "__fc-summary";
    summary.innerHTML = `
      <strong>Form Copilot — Scan Results</strong><br>
      <span class="__fc-dot __fc-dot--green"></span>${counts.high} high confidence<br>
      <span class="__fc-dot __fc-dot--yellow"></span>${counts.medium} medium confidence<br>
      <span class="__fc-dot __fc-dot--red"></span>${counts.none} unmatched
    `;
    document.body.appendChild(summary);
  }

  // ─── AUTOFILL ─────────────────────────────────────────────────

  function setNativeValue(el, value) {
    const proto = Object.getPrototypeOf(el);
    const descriptor =
      Object.getOwnPropertyDescriptor(proto, "value") ||
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value") ||
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value");

    if (descriptor && descriptor.set) {
      descriptor.set.call(el, value);
    } else {
      el.value = value;
    }

    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  // ─── LEARNING SYSTEM ─────────────────────────────────────────

  const domain = window.location.hostname;

  async function loadLearnedMappings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["learned_mappings"], (result) => {
        const all = result.learned_mappings || {};
        resolve(all[domain] || {});
      });
    });
  }

  async function saveLearnedMapping(fieldId, crmKey) {
    return new Promise((resolve) => {
      chrome.storage.local.get(["learned_mappings"], (result) => {
        const all = result.learned_mappings || {};
        if (!all[domain]) all[domain] = {};
        all[domain][fieldId] = crmKey;
        chrome.storage.local.set({ learned_mappings: all }, resolve);
      });
    });
  }

  function fieldIdentifier(field) {
    return [field.name, field.id, field.placeholder, field.label].filter(Boolean).join("|") || null;
  }

  // ─── CORRECTION WATCHER ───────────────────────────────────────

  function watchForCorrections(filledFields, crmData) {
    const crmReverse = {};
    for (const [key, val] of Object.entries(crmData)) {
      if (typeof val === "string") crmReverse[val.toLowerCase()] = key;
    }

    filledFields.forEach(({ field, crmKey }) => {
      const el = field.element;
      const fid = fieldIdentifier(field);
      if (!fid) return;

      const handler = () => {
        const newVal = el.value.trim().toLowerCase();
        if (crmReverse[newVal] && crmReverse[newVal] !== crmKey) {
          const correctedKey = crmReverse[newVal];
          console.log(`[Form Copilot] Learning: "${fid}" → ${correctedKey} (was ${crmKey})`);
          saveLearnedMapping(fid, correctedKey);
        }
        el.removeEventListener("change", handler);
      };
      el.addEventListener("change", handler);
    });
  }

  // ─── SCAN (overlay only) ──────────────────────────────────────

  async function runScan(crmData) {
    clearOverlays();
    injectOverlayStyles();

    const fields = detectFields();
    const learned = await loadLearnedMappings();
    const counts = { high: 0, medium: 0, none: 0 };
    const results = [];

    fields.forEach((field) => {
      const match = matchFieldWithConfidence(field, learned);
      const hasData = match.crmKey && crmData[match.crmKey] !== undefined;
      const level = hasData ? (match.confidence || "none") : "none";

      if (level === "high") counts.high++;
      else if (level === "medium") counts.medium++;
      else counts.none++;

      createOverlay(field.element, level, hasData ? match.crmKey : null);
      results.push({ name: field.name || field.id || field.label, crmKey: match.crmKey, confidence: level });

      console.log(`[Form Copilot] Scan: "${field.name || field.id || field.label}" → ${match.crmKey || "none"} [${level}]`);
    });

    showSummary(counts);
    console.log(`[Form Copilot] Scan complete: ${fields.length} fields (${counts.high} high, ${counts.medium} medium, ${counts.none} unmatched)`);

    return { total: fields.length, ...counts, results };
  }

  // ─── MAIN AUTOFILL FLOW ───────────────────────────────────────

  async function runAutofill(crmData) {
    clearOverlays();

    const fields = detectFields();
    console.log(`[Form Copilot] Detected ${fields.length} fields`);
    console.log("[Form Copilot] CRM DATA:", crmData);

    const learned = await loadLearnedMappings();
    const filledFields = [];
    let filled = 0;

    fields.forEach((field) => {
      const match = matchFieldWithConfidence(field, learned);
      const crmKey = match.crmKey;
      const source = match.source || "none";

      console.log(`[Form Copilot] Field: name="${field.name}" id="${field.id}" placeholder="${field.placeholder}" label="${field.label}" → ${crmKey || "NO MATCH"} (${source})`);

      if (crmKey && crmData[crmKey] !== undefined) {
        setNativeValue(field.element, crmData[crmKey]);
        filled++;
        filledFields.push({ field, crmKey });
        console.log(`[Form Copilot] ✓ Filled "${field.name || field.id || field.label}" → ${crmKey} = "${crmData[crmKey]}"`);
      } else if (crmKey) {
        console.log(`[Form Copilot] ✗ Matched "${field.name || field.id}" → ${crmKey} but no CRM data for that key`);
      }
    });

    watchForCorrections(filledFields, crmData);

    console.log(`[Form Copilot] Autofill complete: ${filled}/${fields.length} fields filled`);
    return { total: fields.length, filled };
  }

  // ─── MUTATION OBSERVER ────────────────────────────────────────

  const observer = new MutationObserver(() => {});
  observer.observe(document.body, { childList: true, subtree: true });

  // ─── MESSAGE LISTENER ────────────────────────────────────────

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "scan") {
      runScan(message.crmData).then((result) => sendResponse(result));
      return true;
    }
    if (message.action === "autofill") {
      runAutofill(message.crmData).then((result) => sendResponse(result));
      return true;
    }
    if (message.action === "clear_overlays") {
      clearOverlays();
      sendResponse({ ok: true });
      return false;
    }
  });
})();
